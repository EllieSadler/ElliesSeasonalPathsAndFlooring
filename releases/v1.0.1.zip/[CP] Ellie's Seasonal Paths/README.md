# Ellie's Seasonal Paths and Flooring

This mod replaces the craftable paths and flooring with new, optionally seasonal versions.

You can turn off any path or floor by setting its "Replace xxx" field to "false".

To turn off the seasonal options and default to the basic summer version from this mod, set "Use Seasonal Versions" to "false".
